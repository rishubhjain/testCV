import cv2
from cv2 import cv
def tomat(image):
    mat= cv.fromarray(image)
    
    
    return mat
