import cv2
import numpy as np

def tuple1(image):
    a=tuple(map(tuple, image))
    return a
