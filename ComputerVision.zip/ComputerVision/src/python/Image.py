import numpy as np

def image(image):
    print type(image)
    return
