import cv2

def HSV2BGR(image):

    bgr = cv2.cvtColor(img,cv2.COLOR_HSV2BGR)
    
    return bgr
