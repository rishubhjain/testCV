

import cv2

def bgr2hsv(image):

    hsv = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)

    return hsv


